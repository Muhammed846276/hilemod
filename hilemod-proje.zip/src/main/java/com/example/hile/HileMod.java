package com.example.hile;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandBuildContext;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/**
 * Okul projesi: tek oyunculu dünya için hile menüsü ve /hile komutları.
 * Her şey normal Minecraft komutlarını (/effect, /gamemode, /give) gönderir,
 * bu yüzden dünyada "hileler açık" olmalı.
 */
public class HileMod implements ClientModInitializer {

    private static KeyMapping menuKey;

    @Override
    public void onInitializeClient() {
        // Varsayılan tuş: Sol Shift. Oyunda Kontroller menüsünden değiştirilebilir.
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.hilemod.menu",
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_LEFT_SHIFT,
            KeyMapping.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (menuKey.consumeClick()) {
                if (mc.player != null && mc.screen == null) {
                    mc.setScreen(new HileScreen());
                }
            }
        });

        ClientCommandRegistrationCallback.EVENT.register(HileMod::registerCommands);
    }

    private static void registerCommands(CommandDispatcher<FabricClientCommandSource> dispatcher,
                                         CommandBuildContext context) {
        dispatcher.register(ClientCommandManager.literal("hile")
            .then(ClientCommandManager.literal("menu").executes(c -> {
                Minecraft.getInstance().execute(() ->
                    Minecraft.getInstance().setScreen(new HileScreen()));
                return 1;
            }))
            .then(ClientCommandManager.literal("yardim").executes(c -> {
                c.getSource().sendFeedback(Component.literal(
                    "/hile: menu, ucma, hiz, ziplama, gece, can, set, creative, survival, temizle"));
                return 1;
            }))
            .then(ClientCommandManager.literal("ucma").executes(c -> run("gamemode creative")))
            .then(ClientCommandManager.literal("creative").executes(c -> run("gamemode creative")))
            .then(ClientCommandManager.literal("survival").executes(c -> run("gamemode survival")))
            .then(ClientCommandManager.literal("hiz").executes(c ->
                run("effect give @s minecraft:speed infinite 4 true")))
            .then(ClientCommandManager.literal("ziplama").executes(c ->
                run("effect give @s minecraft:jump_boost infinite 5 true")))
            .then(ClientCommandManager.literal("gece").executes(c ->
                run("effect give @s minecraft:night_vision infinite 0 true")))
            .then(ClientCommandManager.literal("can").executes(c -> {
                run("effect give @s minecraft:instant_health 1 10 true");
                return run("effect give @s minecraft:saturation 1 10 true");
            }))
            .then(ClientCommandManager.literal("set").executes(c -> {
                run("give @s minecraft:diamond_helmet");
                run("give @s minecraft:diamond_chestplate");
                run("give @s minecraft:diamond_leggings");
                run("give @s minecraft:diamond_boots");
                run("give @s minecraft:diamond_sword");
                return run("give @s minecraft:golden_apple 16");
            }))
            .then(ClientCommandManager.literal("temizle").executes(c ->
                run("effect clear @s")))
        );
    }

    private static int run(String command) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return 0;
        }
        mc.player.connection.sendCommand(command);
        return 1;
    }
}
