package com.example.hile;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Sol Shift ile açılan hile menüsü. */
public class HileScreen extends Screen {

    private static final int BTN_W = 150;
    private static final int BTN_H = 20;
    private static final int GAP = 4;

    public HileScreen() {
        super(Component.literal("Hile Menüsü"));
    }

    @Override
    protected void init() {
        int left = this.width / 2 - BTN_W - GAP / 2;
        int right = this.width / 2 + GAP / 2;
        int y = this.height / 2 - 70;

        addCmd(left, y, "Creative (Uçma)", "gamemode creative");
        addCmd(right, y, "Survival", "gamemode survival");
        y += BTN_H + GAP;
        addCmd(left, y, "Hız", "effect give @s minecraft:speed infinite 4 true");
        addCmd(right, y, "Zıplama", "effect give @s minecraft:jump_boost infinite 5 true");
        y += BTN_H + GAP;
        addCmd(left, y, "Gece Görüşü", "effect give @s minecraft:night_vision infinite 0 true");
        addCmd(right, y, "Can Doldur",
            "effect give @s minecraft:instant_health 1 10 true",
            "effect give @s minecraft:saturation 1 10 true");
        y += BTN_H + GAP;
        addCmd(left, y, "Elmas Set",
            "give @s minecraft:diamond_helmet",
            "give @s minecraft:diamond_chestplate",
            "give @s minecraft:diamond_leggings",
            "give @s minecraft:diamond_boots",
            "give @s minecraft:diamond_sword",
            "give @s minecraft:golden_apple 16");
        addCmd(right, y, "Efektleri Temizle", "effect clear @s");
        y += BTN_H + GAP * 3;

        this.addRenderableWidget(
            Button.builder(Component.literal("Kapat"), b -> this.onClose())
                .bounds(this.width / 2 - BTN_W / 2, y, BTN_W, BTN_H)
                .build());
    }

    private void addCmd(int x, int y, String label, String... commands) {
        this.addRenderableWidget(
            Button.builder(Component.literal(label), b -> {
                    Minecraft mc = Minecraft.getInstance();
                    if (mc.player != null) {
                        for (String cmd : commands) {
                            mc.player.connection.sendCommand(cmd);
                        }
                    }
                })
                .bounds(x, y, BTN_W, BTN_H)
                .build());
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
